#!/bin/sh
#
# Ein Beispiel der DANTE-Edition
#
## Beispiel 03-03-2 auf Seite .
#
# Copyright (C) 2018 Herbert Voss
#
# It may be distributed and/or modified under the conditions
# of the LaTeX Project Public License, either version 1.3
# of this license or (at your option) any later version.
#
# See http://www.latex-project.org/lppl.txt for details.
#
# Running pffonts on Linux
#START

#STOP
#
#CODEbegin
otfinfo -i `kpsewhich texgyrepagella-regular.otf` | head --lines=7
#CODEend
