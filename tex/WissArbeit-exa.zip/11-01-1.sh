#!/bin/sh
#
# Ein Beispiel der DANTE-Edition
#
## Beispiel 11-01-1 auf Seite .
#
# Copyright (C) 2018 Herbert Voss
#
# It may be distributed and/or modified under the conditions
# of the LaTeX Project Public License, either version 1.3
# of this license or (at your option) any later version.
#
# See http://www.latex-project.org/lppl.txt for details.
#
# Running bash on Linux
#!/bin/bash
#START

#STOP
#
#CODEbegin
cat << EOF >test-aux.tex
\documentclass{scrbook}
\begin{document}
\chapter{Einführung} foo bar baz \newpage
\section{baz} foo bar \subsection{foobar}
\end{document}
EOF
#
lualatex test-aux 2&>/dev/null
#-----------------------------------
cat test-aux.aux
#CODEend
