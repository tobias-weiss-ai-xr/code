#!/bin/sh
#
# Ein Beispiel der DANTE-Edition
#
## Beispiel 12-01-2 auf Seite .
#
# Copyright (C) 2018 Herbert Voss
#
# It may be distributed and/or modified under the conditions
# of the LaTeX Project Public License, either version 1.3
# of this license or (at your option) any later version.
#
# See http://www.latex-project.org/lppl.txt for details.
#
# Running bash on Linux
#!/bin/bash
#START

#STOP
#
#CODEbegin
cat << EOF >test-toc.tex
\documentclass{scrbook}
\begin{document}
\tableofcontents
\chapter{Einführung}
foo bar baz \newpage
\section{baz}
foo bar \subsection{foobar}
\end{document}
EOF
#
lualatex test-toc 2&>/dev/null   # erster Durchlauf
lualatex test-toc 2&>/dev/null   # zweiter Durchlauf
#-----------------------------------
cat test-toc.toc                 # test-toc.toc ausgeben
#CODEend
