#!/bin/perl
open(IN,"<lobbylisteamtlich.txt") or die "Find Datei nicht!";
open(OUT,">lobby.txt");
my $pattern = "Name und Sitz";
while (<IN>) {
  if (/^$pattern/) { 
    my $line = <IN>; 
    print OUT "$line";
  }
}
close(IN);
close(OUT);