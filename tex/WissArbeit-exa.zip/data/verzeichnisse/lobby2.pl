#!/bin/perl
open(IN,"<lobbyOrig.txt") or die "Find Datei nicht!";
open(OUT,">glossdata2.txt");
my $para="} ";
my $line="";
my $lineStart = "\\newglossaryentry{";
while (<IN>) {
  chomp;
  my $firstSpace=index($_," ");
#  $line[index($_," ")] = "\}"; 
#  print $line."\n";
  my @woerter=split;
  $woerter[0]=$lineStart.$woerter[0]."\}\{name=\{".$woerter[0]."\},\n\t description=\{";
  my $Zeile = join (" ",@woerter);
#  print $lineStart.$woerter$_;
#    print OUT "$line";
  print OUT $Zeile."\}\}\n";
  }
close(IN);
close(OUT);